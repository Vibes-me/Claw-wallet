/**
 * Test script for Agent Wallet Service
 * Run: node tests/test-wallet.js
 */

const API_URL = 'http://localhost:3000';

async function testHealth() {
  console.log('\n📊 Testing health endpoint...');
  const res = await fetch(`${API_URL}/health`);
  const data = await res.json();
  console.log('Health:', data);
  return res.ok;
}

async function testCreateWallet() {
  console.log('\n🔐 Testing wallet creation...');
  const res = await fetch(`${API_URL}/wallet/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      agentName: 'TestAgent',
      chain: 'base-sepolia'
    })
  });
  const data = await res.json();
  console.log('Wallet created:', data);
  return data.wallet?.address;
}

async function testGetBalance(address) {
  console.log('\n💰 Testing balance check...');
  const res = await fetch(`${API_URL}/wallet/${address}/balance`);
  const data = await res.json();
  console.log('Balance:', data);
}

async function testRegisterIdentity() {
  console.log('\n🆔 Testing identity registration...');
  const res = await fetch(`${API_URL}/identity/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      agentId: 'test-agent-001',
      name: 'Test Agent',
      description: 'A test AI agent',
      walletAddress: '0x1234567890abcdef1234567890abcdef12345678'
    })
  });
  const data = await res.json();
  console.log('Identity:', data);
}

async function runTests() {
  console.log('🦞 Agent Wallet Service Tests');
  console.log('==============================');

  try {
    const healthy = await testHealth();
    if (!healthy) {
      console.log('❌ Server not running. Start with: npm start');
      return;
    }

    const address = await testCreateWallet();
    if (address) {
      await testGetBalance(address);
    }

    await testRegisterIdentity();

    console.log('\n✅ All tests completed!');
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

runTests();
